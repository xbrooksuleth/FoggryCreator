var head1 = '<img src="imgs/head1.png" class = \"part part-head\">'
var head2 = '<img src="imgs/head2.png" class = \"part part-body\">'
var head3 = '<img src="imgs/head3.png" class = \"part part-body\">'
var heads = [head1, head2, head3]

var body1 = '<img src="imgs/body1.png" class = \"part part-head\">'
var body2 = '<img src="imgs/body2.png" class = \"part part-body\">'
var body3 = '<img src="imgs/body3.png" class = \"part part-body\">'
var bodys = [body1, body2, body3]

var feet1 = '<img src="imgs/feet1.png" class = \"part part-head\">'
var feet2 = '<img src="imgs/feet2.png" class = \"part part-body\">'
var feet3 = '<img src="imgs/feet3.png" class = \"part part-body\">'
var feets = [feet1, feet2, feet3]

var hcolors = ["#fcba03", "#00bae8", "#e400e8"]
var bcolors = ["#997000", "#0087a8", "#8c008f"]
var fcolors = ["#614700", "#015c73", "#440045"]

function updateHead() {
    var randomNum = Math.floor(Math.random()*heads.length)
    $(".headhtml").html(heads[randomNum])
}

function updateBody() {
    var randomNum = Math.floor(Math.random()*heads.length)
    $(".bodyhtml").html(bodys[randomNum])
}

function updateFeet() {
    var randomNum = Math.floor(Math.random()*heads.length)
    $(".feethtml").html(feets[randomNum])
}

function updateColor() {
    var randomNum = Math.floor(Math.random()*hcolors.length)
    $(".headhtml").css("background-color", hcolors[randomNum])
    $(".bodyhtml").css("background-color", bcolors[randomNum])
    $(".feethtml").css("background-color", fcolors[randomNum])
}

$(".headhtml").on("click", updateHead)
$(".bodyhtml").on("click", updateBody)
$(".feethtml").on("click", updateFeet)

$(document).on("keypress", function(e){ 
    if (e.key == '1'){
        updateHead()
        updateBody()
        updateFeet()
    }
    if (e.key == '2'){
        updateColor()
    }
})